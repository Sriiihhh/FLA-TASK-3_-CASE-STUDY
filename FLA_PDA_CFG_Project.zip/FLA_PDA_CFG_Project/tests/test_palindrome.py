
from case_studies.palindrome import is_palindrome

def test_valid_palindromes():
    assert is_palindrome("a")
    assert is_palindrome("b")
    assert is_palindrome("aa")
    assert is_palindrome("abba")
    assert is_palindrome("aba")
    assert is_palindrome("baab")
    assert is_palindrome("aabbaa")
    assert is_palindrome("")

def test_invalid_palindromes():
    assert not is_palindrome("ab")
    assert not is_palindrome("aab")
    assert not is_palindrome("abb")
    assert not is_palindrome("aabb")
    assert not is_palindrome("babaa")
