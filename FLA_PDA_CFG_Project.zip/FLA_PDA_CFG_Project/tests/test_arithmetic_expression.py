
from case_studies.arithmetic_expression import validate_expression

def test_valid_expressions():
    assert validate_expression("id+id")
    assert validate_expression("id*id")
    assert validate_expression("id+id*id")
    assert validate_expression("(id+id)*id")
    assert validate_expression("id*(id+id)")

def test_invalid_expressions():
    assert not validate_expression("id+")
    assert not validate_expression("*id")
    assert not validate_expression("id++id")
    assert not validate_expression("(id+id")
    assert not validate_expression("id id")
