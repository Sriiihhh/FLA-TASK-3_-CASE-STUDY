
from case_studies.balanced_brackets import balanced_brackets

def test_balanced_brackets():
    assert balanced_brackets("()") == True
    assert balanced_brackets("(())") == True
    assert balanced_brackets("()()") == True
    assert balanced_brackets("(()())") == True
    assert balanced_brackets("((()))") == True

def test_unbalanced_brackets():
    assert balanced_brackets("(") == False
    assert balanced_brackets(")") == False
    assert balanced_brackets("(()") == False
    assert balanced_brackets("())") == False
    assert balanced_brackets("(()))") == False
