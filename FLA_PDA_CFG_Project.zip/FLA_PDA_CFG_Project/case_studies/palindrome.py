
def is_palindrome(string):
    stack = []

    # Push the first half of the string
    for char in string[:len(string)//2]:
        stack.append(char)

    # Skip the middle character for odd-length strings
    if len(string) % 2 != 0:
        second_half = string[len(string)//2 + 1:]
    else:
        second_half = string[len(string)//2:]

    # Compare the second half with the stack
    for char in second_half:
        if not stack:
            return False

        if stack.pop() != char:
            return False

    return len(stack) == 0
