# Case Study 2: Arithmetic Expression Validation Using CFG and PDA

## 2.1 Problem Definition

Arithmetic expressions are commonly used in programming languages and mathematical calculations. Every expression must follow specific syntax rules to be considered valid.

The objective of this case study is to design a Context-Free Grammar (CFG) and a Pushdown Automaton (PDA) to validate arithmetic expressions containing identifiers, addition, multiplication and parentheses.

The system accepts valid expressions such as `id+id`, `id*id` and `(id+id)*id`, while rejecting invalid expressions such as `id+`, `*id` and `id++id`.

## 2.2 Target Language

The input alphabet consists of:

Σ = { id, +, *, (, ) }

The language contains all syntactically valid arithmetic expressions formed using identifiers, addition, multiplication and parentheses.

Examples:

**Accepted:** `id+id`, `id*id`, `id+id*id`, `(id+id)*id`

**Rejected:** `id+`, `*id`, `id++id`, `(id+id`

## 2.3 Initial Context-Free Grammar

Consider the following grammar:

E → E + E | E * E | (E) | id

Here, E is the starting variable and id represents an identifier.

This grammar generates arithmetic expressions but is ambiguous because it does not specify operator precedence.

## 2.4 Ambiguity Analysis

The initial grammar E → E+E | E*E | (E) | id is ambiguous.

For the expression id+id*id, two different parse trees are possible:

1. id+(id*id)
2. (id+id)*id

These interpretations produce different results depending on the values assigned to the identifiers.

## 2.5 Revised Unambiguous Grammar

To eliminate ambiguity and establish operator precedence, the grammar is revised as follows:

E → E+T | T

T → T*F | F

F → (E) | id

Here:
- E represents an arithmetic expression and handles addition.
- T represents a term and handles multiplication.
- F represents a factor and handles identifiers or parenthesized expressions.

This grammar ensures that multiplication has higher precedence than addition and provides an unambiguous structure for arithmetic expressions.

## 2.6 Leftmost Derivation

Consider the expression:

id+id*id

Using the revised grammar, the leftmost derivation is:

E ⇒ E+T

⇒ T+T

⇒ F+T

⇒ id+T

⇒ id+T*F

⇒ id+F*F

⇒ id+id*F

⇒ id+id*id

The derivation demonstrates that multiplication is grouped within the T production, ensuring higher precedence than addition.

## 2.7 Parse Tree

The parse tree represents the hierarchical structure of the arithmetic expression id+id*id.

The root represents E, addition is handled at the expression level, and multiplication is handled within the term level.

This structure ensures that multiplication is evaluated before addition.

## 2.8 PDA Stack Processing

The PDA uses a stack to simulate predictive parsing.

| Stack symbol | Input condition | Operation |
|---|---|---|
| E | Any valid expression start | Replace E with TE' |
| E' | + | Replace E' with +TE' |
| E' | ) or end of input | Remove E' (epsilon) |
| T | Any valid term start | Replace T with FT' |
| T' | * | Replace T' with *FT' |
| T' | +, ), or end of input | Remove T' (epsilon) |
| F | id | Replace F with id |
| F | ( | Replace F with (E) |
| Terminal | Same input symbol | Match and consume |
| Terminal | Different input symbol | Reject |


## 2.9 Accepted and Rejected Strings

### Accepted Strings

| Expression | Reason |
|---|---|
| id+id | Valid addition |
| id*id | Valid multiplication |
| id+id*id | Valid precedence |
| (id+id)*id | Valid parenthesized expression |
| id*(id+id) | Valid nested expression |

### Rejected Strings

| Expression | Reason |
|---|---|
| id+ | Missing operand |
| *id | Operator without left operand |
| id++id | Consecutive operators |
| (id+id | Missing closing parenthesis |
| id id | Missing operator |

## 2.10 Conclusion

The arithmetic expression validator uses a Context-Free Grammar to define valid expressions and a stack-based parsing approach to recognize them. The grammar handles operator precedence and parentheses. The Python implementation successfully validates correct expressions and rejects syntactically invalid ones.


## 2.11 Formal PDA Definition

The arithmetic expression language is recognized using a Nondeterministic Pushdown Automaton (NPDA) constructed from the Context-Free Grammar.

The PDA is defined as:

M = (Q, Σ, Γ, δ, q0, Z0, F)

Where:

- Q = {q0}
- Σ = {id, +, *, (, )}
- Γ = {E, T, F, +, *, (, ), id, Z0}
- q0 = Initial state
- Z0 = Initial stack symbol
- F = ∅

The PDA accepts by empty stack.

### 2.12 PDA Transition Rules

**1. Initialize the stack**

Push the start symbol E above Z0.

**2. Expand non-terminals**

The PDA uses the following grammar productions:

- E → E + T
- E → T
- T → T * F
- T → F
- F → (E)
- F → id

**3. Match terminals**

When the top of the stack matches the next input symbol, consume the input symbol and pop the stack symbol.

**4. Acceptance**

The string is accepted when all input symbols have been consumed and the stack becomes empty after removing Z0.
