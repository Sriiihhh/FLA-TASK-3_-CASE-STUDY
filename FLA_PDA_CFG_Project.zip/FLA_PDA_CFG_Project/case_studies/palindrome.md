
# Case Study 3: Palindrome Checking

## 3.1 Problem Definition

A palindrome is a string that reads the same forward and backward. The objective is to design a Context-Free Grammar (CFG) and Pushdown Automaton (PDA) to recognize palindromes over the alphabet {a, b}.

Examples include aba, abba, aabbaa and baab.

## 3.2 Target Language

Alphabet:

Σ = {a, b}

The language consists of all strings that are equal to their reverse.

Accepted strings:
- a
- b
- aa
- bb
- aba
- abba
- baab
- aabbaa
- ε (empty string)

Rejected strings:
- ab
- aab
- abb
- aabb
- babaa

## 3.3 Initial Context-Free Grammar

The grammar is:

S → aSa | bSb | a | b | ε

Where:
- S is the start symbol.
- a and b are terminal symbols.
- ε represents the empty string.

The productions add the same symbol to both ends of the string, ensuring that the generated strings are palindromes.

## 3.4 Grammar Analysis

The grammar generates both even-length and odd-length palindromes.

For example:
- S → ε generates the empty string.
- S → a generates a single-character palindrome.
- S → aSa → aba generates an odd-length palindrome.
- S → aSa → abba generates an even-length palindrome.

The grammar is unambiguous because each palindrome has a unique choice of outermost symbols and a unique smaller palindrome inside.


## 3.5 Derivation of the String "abba"

S ⇒ aSa

⇒ abSba

⇒ abεba

⇒ abba

This derivation demonstrates how the grammar generates a palindrome by adding matching symbols to both ends.


## 3.6 Formal PDA Definition

The palindrome language is recognized using a Nondeterministic Pushdown Automaton (NPDA).

The PDA is defined as:

M = (Q, Σ, Γ, δ, q0, Z0, F)

Where:

- Q = {q0, q1, qf}
- Σ = {a, b}
- Γ = {a, b, Z0}
- q0 = Initial state
- Z0 = Initial stack symbol
- F = {qf}


### 3.7 PDA Transition Rules

Let X represent any stack symbol in {a, b, Z0}.

**Phase 1: Push the first half**

- δ(q0, a, X) = (q0, aX)
- δ(q0, b, X) = (q0, bX)

**Phase 2: Guess the midpoint**

For even-length strings:
- δ(q0, ε, X) = (q1, X)

For odd-length strings:
- δ(q0, a, X) = (q1, X)
- δ(q0, b, X) = (q1, X)

**Phase 3: Match the second half**

- δ(q1, a, a) = (q1, ε)
- δ(q1, b, b) = (q1, ε)

**Acceptance:**

- δ(q1, ε, Z0) = (qf, Z0)

The PDA accepts only when the entire input has been consumed and the stack has returned to its initial bottom symbol Z0.


### 3.8 Example Processing: "abba"

1. Read a and push it.
2. Read b and push it.
3. Guess the midpoint.
4. Read b and pop b.
5. Read a and pop a.
6. Input is exhausted and only Z0 remains.

Therefore, "abba" is accepted.

### 3.9 Determinism Analysis

The palindrome language over {a, b} requires a nondeterministic PDA because the machine cannot determine the midpoint before reading the input.

The NPDA guesses the midpoint and then compares the remaining symbols with the stack contents.

### 3.10 Conclusion

The palindrome checker demonstrates how a stack can be used to recognize strings that read identically in both directions. The CFG generates palindromes, while the NPDA recognizes them by guessing the midpoint and matching symbols in reverse order.
