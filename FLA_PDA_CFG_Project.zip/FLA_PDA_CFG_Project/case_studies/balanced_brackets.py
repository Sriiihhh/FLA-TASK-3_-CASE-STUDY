
def balanced_brackets(string):
    stack = []

    print("\nPDA Processing:")
    print("---------------------------")
    print("Input\tStack\t\tAction")

    for symbol in string:

        if symbol == '(':
            stack.append(symbol)
            print(f"{symbol}\t{stack}\t\tPush")

        elif symbol == ')':

            if len(stack) == 0:
                print(f"{symbol}\t{stack}\t\tReject")
                return False

            stack.pop()
            print(f"{symbol}\t{stack}\t\tPop")

        else:
            print(f"{symbol}\t{stack}\t\tInvalid symbol")
            return False

    if len(stack) == 0:
        print("\nOnly bottom symbol Z0 remains.")
        print("Transition: q0 -> qf")
        return True

    else:
        print("\nUnmatched opening brackets remain.")
        return False



