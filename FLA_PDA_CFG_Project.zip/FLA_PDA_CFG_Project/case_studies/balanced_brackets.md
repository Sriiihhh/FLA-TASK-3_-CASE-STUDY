# Case Study 1: Balanced Brackets Checker Using CFG and PDA

## 1.1 Problem Definition

Balanced brackets are an important concept in programming languages and mathematical expressions. An expression is considered balanced when every opening parenthesis has a corresponding closing parenthesis in the correct order.

The objective of this case study is to design a Context-Free Grammar (CFG) and a Pushdown Automaton (PDA) to recognize balanced parentheses.

The system accepts valid expressions such as `()`, `(())`, and `()()` and rejects invalid expressions such as `(()` and `())`.

## 1.2 Target Language

Let the alphabet be:

Σ = { (, ) }

The target language consists of all strings containing properly balanced parentheses, including the empty string.

Examples:

**Accepted:** `()`, `(())`, `()()`, `(()())`

**Rejected:** `(`, `)`, `(()`, `())`

## 1.3 Pushdown Automaton Design

## 1.4 PDA Components

## 1.5 Transition Function

## 1.6 PDA State Diagram

## 1.7 Stack Processing Example

## 1.8 Ambiguity Analysis

An ambiguous Context-Free Grammar is a grammar that generates at least one string with more than one distinct parse tree.

Consider the grammar:

S → SS | (S) | ε

This grammar can generate balanced parentheses but may produce multiple parse trees for the same string because the SS production allows different groupings.

To avoid ambiguity, we use the revised grammar:

S → (S)S | ε

This grammar is unambiguous because every non-empty balanced string has a unique decomposition into its first balanced parenthesized group and the remaining balanced string.

Therefore, the revised grammar provides a unique structural representation for every valid string.

## 1.9 Determinism Analysis

The balanced parentheses language can be recognized by a Deterministic Pushdown Automaton (DPDA).

The PDA pushes an opening parenthesis onto the stack and pops it when a matching closing parenthesis is encountered.

An unmatched closing parenthesis is rejected immediately. If the input ends with unmatched opening parentheses, the stack will contain extra symbols and the string is rejected.

Thus, the language of balanced parentheses is deterministic context-free.