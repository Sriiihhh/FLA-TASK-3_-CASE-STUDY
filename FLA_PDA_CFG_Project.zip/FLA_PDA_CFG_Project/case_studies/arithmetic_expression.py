
def validate_expression(expression):
    tokens = expression.replace(" ", "").split()

    # Tokenize identifiers and operators
    import re
    tokens = re.findall(r'id|[+*()]', expression.replace(" ", ""))

    # Reject invalid characters
    if "".join(tokens) != expression.replace(" ", ""):
        return False

    position = 0

    def parse_expression():
        nonlocal position
        if not parse_term():
            return False

        while position < len(tokens) and tokens[position] == "+":
            position += 1
            if not parse_term():
                return False

        return True

    def parse_term():
        nonlocal position
        if not parse_factor():
            return False

        while position < len(tokens) and tokens[position] == "*":
            position += 1
            if not parse_factor():
                return False

        return True

    def parse_factor():
        nonlocal position

        if position >= len(tokens):
            return False

        if tokens[position] == "id":
            position += 1
            return True

        if tokens[position] == "(":
            position += 1

            if not parse_expression():
                return False

            if position >= len(tokens) or tokens[position] != ")":
                return False

            position += 1
            return True

        return False

    return parse_expression() and position == len(tokens)
