
from graphviz import Digraph

# Create PDA diagram
dot = Digraph("Balanced_Brackets_PDA")

dot.attr(rankdir="LR", bgcolor="white")
dot.attr("node", shape="circle", style="filled",
         fillcolor="lightblue", fontname="Arial")

# Initial and final states
dot.node("start", "", shape="point",
         width="0.12", color="black")
dot.node("q0", "q0")
dot.node("qf", "qf", shape="doublecircle",
         fillcolor="lightgreen")

# Initial transition
dot.edge("start", "q0")

# PDA transitions
dot.edge("q0", "q0", label="(, Z0 → (Z0")
dot.edge("q0", "q0", label="(, ( → ((")
dot.edge("q0", "q0", label="), ( → ε")

# Accept when only bottom symbol remains
dot.edge("q0", "qf", label="ε, Z0 → Z0")

# Save diagram
dot.render(
    "diagrams/balanced_brackets_pda",
    format="png",
    cleanup=True
)

print("PDA diagram generated successfully!")
