
from graphviz import Digraph

dot = Digraph("Palindrome_NPDA")

dot.attr(rankdir="LR", bgcolor="white")
dot.attr("node", fontname="Arial", style="filled",
         fillcolor="lightblue")

dot.node("start", "", shape="point")
dot.node("q0", "q0\nPush first half")
dot.node("q1", "q1\nMatch second half")
dot.node("qf", "qf\nAccepted",
         shape="doublecircle", fillcolor="lightgreen")

dot.edge("start", "q0")

# Push symbols onto the stack
dot.edge("q0", "q0",
         label="a, X → aX\nb, X → bX")

# Guess the midpoint of an even-length palindrome
dot.edge("q0", "q1",
         label="ε, X → X\nEven midpoint")

# Consume the middle symbol of an odd-length palindrome
dot.edge("q0", "q1",
         label="a, X → X\nb, X → X\nOdd midpoint")

# Match the remaining input with the stack
dot.edge("q1", "q1",
         label="a, a → ε\nb, b → ε")

# Accept when input is exhausted and only Z0 remains
dot.edge("q1", "qf",
         label="ε, Z₀ → Z₀")

dot.render("diagrams/palindrome_pda",
           format="png", cleanup=True)

print("Corrected Palindrome NPDA diagram generated!")
