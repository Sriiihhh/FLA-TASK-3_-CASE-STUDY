
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, FancyArrowPatch

fig, ax = plt.subplots(figsize=(16, 9))

ax.set_xlim(-6, 6)
ax.set_ylim(-4, 4)
ax.axis("off")

# Draw states
states = {
    "q0": (-4, 0),
    "q1": (0, 0),
    "qf": (4, 0)
}

for name, (x, y) in states.items():
    circle = Circle((x, y), 0.48, facecolor="lightblue",
                    edgecolor="black", linewidth=2)
    ax.add_patch(circle)
    ax.text(x, y, name, ha="center", va="center", fontsize=16)

# Initial arrow
ax.annotate("", xy=(-4.5, 0), xytext=(-5.5, 0),
            arrowprops=dict(arrowstyle="->", lw=2))

# q0 to q1
ax.annotate("", xy=(-0.5, 0), xytext=(-3.5, 0),
            arrowprops=dict(arrowstyle="->", lw=2))

ax.text(-2, 0.35, "ε, Z0 → EZ0",
        ha="center", fontsize=12)

# Grammar expansion loop above q1
upper_loop = FancyArrowPatch(
    (-0.35, 0.35), (0.35, 0.35),
    connectionstyle="arc3,rad=-2.2",
    arrowstyle="->", mutation_scale=18,
    linewidth=2
)
ax.add_patch(upper_loop)

ax.text(0, 2.4,
        "GRAMMAR EXPANSION\n\n"
        "ε, E → E+T | T\n"
        "ε, T → T*F | F\n"
        "ε, F → (E) | id",
        ha="center", va="center", fontsize=12,
        bbox=dict(boxstyle="round,pad=0.6",
                  facecolor="lightyellow", edgecolor="black"))

# Terminal matching loop below q1
lower_loop = FancyArrowPatch(
    (0.35, -0.35), (-0.35, -0.35),
    connectionstyle="arc3,rad=-2.2",
    arrowstyle="->", mutation_scale=18,
    linewidth=2
)
ax.add_patch(lower_loop)

ax.text(0, -2.4,
        "TERMINAL MATCHING\n\n"
        "a, a → ε\n"
        "a ∈ {id, +, *, (, )}",
        ha="center", va="center", fontsize=12,
        bbox=dict(boxstyle="round,pad=0.6",
                  facecolor="lightgreen", edgecolor="black"))

# q1 to final state
ax.annotate("", xy=(3.5, 0), xytext=(0.5, 0),
            arrowprops=dict(arrowstyle="->", lw=2))

ax.text(2, 0.4, "ε, Z0 → ε",
        ha="center", fontsize=12)

ax.text(4, -0.85, "Accepted by empty stack",
        ha="center", fontsize=11)

plt.title("Arithmetic Expression – CFG-based NPDA",
          fontsize=18, pad=20)

plt.savefig("diagrams/arithmetic_expression_pda.png",
            dpi=200, bbox_inches="tight")

plt.close()

print("Arithmetic expression NPDA diagram generated!")
