
from graphviz import Digraph

dot = Digraph("Arithmetic_Parse_Tree")

dot.attr(
    rankdir="TB",
    bgcolor="white",
    ordering="out"
)

dot.attr(
    "node",
    shape="circle",
    style="filled",
    fillcolor="lightblue",
    fontname="Arial"
)

# Grammar tree
dot.node("E", "E")
dot.node("E1", "E")
dot.node("T1", "T")
dot.node("T2", "T")
dot.node("T3", "T")
dot.node("F1", "F")
dot.node("F2", "F")
dot.node("F3", "F")

# Leaves
dot.node("id1", "id", shape="box", fillcolor="lightgreen")
dot.node("plus", "+", shape="box", fillcolor="lightyellow")
dot.node("star", "*", shape="box", fillcolor="lightyellow")
dot.node("id2", "id", shape="box", fillcolor="lightgreen")
dot.node("id3", "id", shape="box", fillcolor="lightgreen")

# Connections
dot.edge("E", "E1")
dot.edge("E", "plus")
dot.edge("E", "T1")

dot.edge("E1", "T2")
dot.edge("T2", "F1")
dot.edge("F1", "id1")

dot.edge("T1", "T3")
dot.edge("T1", "star")
dot.edge("T1", "F2")

dot.edge("T3", "F3")
dot.edge("F3", "id2")
dot.edge("F2", "id3")

dot.render(
    "diagrams/arithmetic_parse_tree",
    format="png",
    cleanup=True
)

print("Arithmetic parse tree generated!")
