
from nltk import CFG
from nltk.parse import ChartParser
from nltk.tree import Tree
from graphviz import Digraph
from itertools import count
from pathlib import Path

# Save generated images inside the diagrams folder
OUTPUT = Path(__file__).parent


def draw_tree(tree, filename, title):
    """Convert an NLTK parse tree into a PNG image."""
    dot = Digraph(format="png")
    dot.attr(rankdir="TB", label=title, labelloc="t")
    dot.attr("node", style="filled", fillcolor="lightblue")

    node_counter = count()

    def add_node(item, parent=None):
        node_id = f"node{next(node_counter)}"

        if isinstance(item, Tree):
            dot.node(node_id, str(item.label()), shape="ellipse")
            for child in item:
                add_node(child, node_id)
        else:
            dot.node(node_id, str(item), shape="box")

        if parent:
            dot.edge(parent, node_id)

    add_node(tree)

    path = OUTPUT / filename
    dot.render(filename=str(path.with_suffix("")), cleanup=True)
    print(f"Image saved: {path}")


def check_grammar(title, grammar_text, test_strings,
                  tokenizer, image_prefix):

    print("\n" + "=" * 55)
    print(title)
    print("=" * 55)

    grammar = CFG.fromstring(grammar_text)
    parser = ChartParser(grammar)

    for string in test_strings:
        tokens = tokenizer(string)
        trees = list(parser.parse(tokens))

        print(f"\nInput: {string}")
        print(f"Parse trees found: {len(trees)}")

        if len(trees) == 0:
            print("Rejected by grammar.")

        elif len(trees) == 1:
            print("Only one parse tree found.")

        else:
            print("AMBIGUOUS: Multiple parse trees found!")

        # Save up to two parse-tree images
        for i, tree in enumerate(trees[:2], start=1):
            draw_tree(
                tree,
                f"{image_prefix}_{string.replace('*', 'mul').replace('+', 'plus')}_{i}.png",
                f"{title} - Parse Tree {i}"
            )


# --------------------------------------------------
# CASE STUDY 1: BALANCED BRACKETS
# --------------------------------------------------

balanced_ambiguous = """
S -> S S
S -> '(' S ')'
S -> '[' S ']'
S -> '{' S '}'
S -> '(' ')'
S -> '[' ']'
S -> '{' '}'
"""

balanced_revised = """
S -> B S
S -> B
B -> '(' S ')'
B -> '[' S ']'
B -> '{' S '}'
B -> '(' ')'
B -> '[' ']'
B -> '{' '}'
"""

bracket_tests = ["()()()", "()()()()"]

check_grammar(
    "BALANCED BRACKETS - ORIGINAL GRAMMAR",
    balanced_ambiguous,
    bracket_tests,
    list,
    "balanced_original"
)

check_grammar(
    "BALANCED BRACKETS - REVISED GRAMMAR",
    balanced_revised,
    bracket_tests,
    list,
    "balanced_revised"
)


# --------------------------------------------------
# CASE STUDY 2: ARITHMETIC EXPRESSIONS
# --------------------------------------------------

arithmetic_ambiguous = """
E -> E '+' E
E -> E '*' E
E -> '(' E ')'
E -> 'id'
"""

arithmetic_revised = """
E -> E '+' T
E -> T
T -> T '*' F
T -> F
F -> '(' E ')'
F -> 'id'
"""

def tokenize_expression(expression):
    import re
    return re.findall(r'id|[+*()]', expression)


expression_tests = ["id+id*id"]

check_grammar(
    "ARITHMETIC - ORIGINAL GRAMMAR",
    arithmetic_ambiguous,
    expression_tests,
    tokenize_expression,
    "arithmetic_original"
)

check_grammar(
    "ARITHMETIC - REVISED GRAMMAR",
    arithmetic_revised,
    expression_tests,
    tokenize_expression,
    "arithmetic_revised"
)


# --------------------------------------------------
# CASE STUDY 3: PALINDROMES
# --------------------------------------------------

palindrome_grammar = """
S -> 'a' S 'a'
S -> 'b' S 'b'
S -> 'a'
S -> 'b'
S ->
"""

palindrome_tests = ["abba", "aba", "baab"]

check_grammar(
    "PALINDROME GRAMMAR",
    palindrome_grammar,
    palindrome_tests,
    list,
    "palindrome"
)


print("\n" + "=" * 55)
print("BOUNDED AMBIGUITY CHECK COMPLETED")
print("All generated PNG images are saved in the diagrams folder.")
print("=" * 55)
